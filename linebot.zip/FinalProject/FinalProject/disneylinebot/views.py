from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
 
from linebot import LineBotApi, WebhookParser
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import ( MessageEvent,
    TextSendMessage,
    TemplateSendMessage,
    ButtonsTemplate,
    MessageTemplateAction,
    URITemplateAction,
    PostbackTemplateAction,
    CarouselTemplate
) # 插入想要套入的套件

#導入scraper.py的netflixScrape Class
from .scrape import netflixScrape
import time
 
line_bot_api = LineBotApi(settings.LINE_CHANNEL_ACCESS_TOKEN)
parser = WebhookParser(settings.LINE_CHANNEL_SECRET)
 
 

@csrf_exempt
def callback(request):
 
    import random

    GerneDict ={'冒險動作片':1365,'動畫':7424,'親子片':783,'經典電影':31574,'喜劇':6548,'Cult片':7627
        ,'紀錄片':6839,'劇情電影':5763,'信仰電影':26835,'多元性別':5977,'恐怖片':8711,'浪漫電影':8883,
        '科幻題材':1492,'運動類型':4370,'驚悚電影':8933,'電視節目':83
        }

    if request.method == 'POST':
        signature = request.META['HTTP_X_LINE_SIGNATURE']
        body = request.body.decode('utf-8')
 
        try:
            # 傳入的事件
            events = parser.parse(body, signature)  
            #顯示訊息傳送的userID,text,type
            print(events) 
        except InvalidSignatureError:
            return HttpResponseForbidden()
        except LineBotApiError:
            return HttpResponseBadRequest()

           


        for event in events:
            

            if isinstance(event, MessageEvent):  # 如果有訊息事件
                    if event.message.text == "打開選單" or  event.message.text == "重新選擇":
                        
                        GerneList = random.sample(GerneDict.keys(), 3)

                        line_bot_api.reply_message(  # 回復傳入的訊息文字
                            event.reply_token,
                            TemplateSendMessage(
                                alt_text='Buttons template',
                                template=ButtonsTemplate(
                                    title='影視分類',
                                    text='請選擇類型',
                                    actions=[
                                        MessageTemplateAction(
                                            label=GerneList[0],
                                            text=GerneList[0]
                                        ),
                                        MessageTemplateAction(
                                            label=GerneList[1],
                                            text=GerneList[1]
                                        ),
                                        MessageTemplateAction(
                                            label=GerneList[2],
                                            text=GerneList[2] 
                                        ),
                                        MessageTemplateAction(
                                            label='重新選擇',
                                            text='重新選擇' 
                                        )
                                    ]
                                )
                            )
                        )
                        
                    elif event.message.text in GerneDict:
                        netflix = netflixScrape(event.message.text)  #建構類別存入使用者傳入的訊息文字

                        line_bot_api.reply_message(
                                event.reply_token, 
                                netflix.scrape()
                                )                        
                    else:

                        line_bot_api.reply_message(
                                event.reply_token
                                , TemplateSendMessage(
                                    alt_text='Buttons template',
                                    template=ButtonsTemplate(
                                    title='歡迎來到NETFLIX資訊站',
                                    text='請選擇功能',
                                    actions=[
                                        MessageTemplateAction(
                                            label='打開選單',
                                            text='打開選單')
                                            ]
                                            )
                                        )       
                                    )             
                   
        return HttpResponse()
    else:
        return HttpResponseBadRequest()