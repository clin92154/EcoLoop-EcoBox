    
from .scrape import netflix

class netflixScrape(netflix):

    
    def scrape(self):
            #取得網站所有內容
            response = requests.get(
                'https://www.netflix.com/tw/browse/genre/' + self.gerneNum
            )

            #解析網頁原始碼
            soup = BeautifulSoup(response.content, "lxml")

            cards = soup.find(
                'ul',{'class':'nm-content-horizontal-row-item-container'})
            
            genreTitle = soup.find(
                'div',{'class':'nm-collections-metadata-title'}
                ).get_text()

            content = '*******' + '前五名' + genreTitle + '*******'
            
            count = 0

            for card in cards:
                if count < 5:
                    title = card.find(
                        'span',{'class':'nm-collections-title-name'}
                    ).get_text()
                    
                    link = card.find(
                    'a',{'class':'nm-collections-title nm-collections-link'}
                    ).get('href')
                    
                    #將取得的作品名稱、連結一起，並且指派給content變數
                    content += f"\n 名稱: {title} \n 連結:{link} \n"
                    count+=1
                else:
                    break

                

            return content


    def scrape2(self):
        #取得網站所有內容
        response = requests.get(
            'https://www.netflix.com/tw/browse/genre/' + self.gerneNum
        )

        #解析網頁原始碼
        soup = BeautifulSoup(response.content, "lxml")

        cards = soup.find(
            'ul',{'class':'nm-content-horizontal-row-item-container'})
        
        genreTitle = soup.find(
            'div',{'class':'nm-collections-metadata-title'}
            ).get_text()

        content = '*******' + '前五名' + genreTitle + '*******'
        
        count = 0

        for card in cards:
            if count < 5:
                title = card.find(
                    'span',{'class':'nm-collections-title-name'}
                ).get_text()
                
                link = card.find(
                'a',{'class':'nm-collections-title nm-collections-link'}
                ).get('href')

                photo = card.find(
                'img',{'class':'nm-collections-title-img'}
                ).get('src')

                count+=1
            else:
                break

            buttons_template = TemplateSendMessage(
                alt_text='Buttons Template',
                template=ButtonsTemplate(
                title= '電影名稱',
                text=title,
                thumbnail_image_url=photo,
                actions=[
                        URITemplateAction(
                                    label='即刻觀賞',
                                    uri=link
                                ), MessageTemplateAction(
                                label='打開選單',
                                text='打開選單'
                            )]
                                
                        )
                    ) 
            return  buttons_template    

