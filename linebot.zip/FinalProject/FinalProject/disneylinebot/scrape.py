from bs4 import BeautifulSoup 
from abc import ABC, abstractmethod
from linebot.models.events import ThingsEvent
import requests 
import time
from linebot import LineBotApi, WebhookParser
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import ( MessageEvent,
    TextSendMessage,
    TemplateSendMessage,
    ButtonsTemplate,
    MessageTemplateAction,
    URITemplateAction,
    PostbackTemplateAction,
    CarouselTemplate,
     CarouselColumn
) # 插入想要套入的套件




#繼承Abstract Base Class類別，為了使用抽象方法
class netflix(ABC):

    #建立初始變數
    def __init__(self, gerneName):
        GerneDict = {'冒險動作片':1365,'動畫':7424,'親子片':783,'經典電影':31574,'喜劇':6548,'Cult片':7627
        ,'紀錄片':6839,'劇情電影':5763,'信仰電影':26835,'多元性別':5977,'恐怖片':8711,'浪漫電影':8883,
        '科幻題材':1492,'運動類型':4370,'驚悚電影':8933,'電視節目':83
        }

        self.gerneNum = str(GerneDict[gerneName]) # 影音類別編號

    #netflix抽象類別，無法建立物件
    @abstractmethod
    def scrape(self):
        pass

#抓取網站內容類別
class netflixScrape(netflix):

    def altText(url):
        
        response = requests.get(url)
            #解析網頁原始碼
        soup = BeautifulSoup(response.content, "lxml")

        content = soup.find(
                    'span',{'class':'title-data-info-item-list'}
                    ).get_text()
        return content

    def scrape(self):
        #儲存作品的卡片集
        movieList = []

        #取得網站所有內容
        response = requests.get(
            'https://www.netflix.com/tw/browse/genre/' + self.gerneNum
        )

        #解析網頁原始碼
        soup = BeautifulSoup(response.content, "lxml")

        cards = soup.find(
            'ul',{'class':'nm-content-horizontal-row-item-container'})
        

        count = 0

        for card in cards:
            if count < 5:
                #標題
                title = card.find(
                    'span',{'class':'nm-collections-title-name'}
                ).get_text()
                #連結
                link = card.find(
                'a',{'class':'nm-collections-title nm-collections-link'}
                ).get('href')

                #飾演
                content = "飾演:"+ netflixScrape.altText(link)
                
                #圖片
                photo = card.find(
                'img',{'class':'nm-collections-title-img'}
                ).get('src')
                
                #新增CarouselColumn格式，存入該作品的資料
                movieList.append(
                     CarouselColumn(
                        thumbnail_image_url=photo,
                        title=title,
                        text=content,
                        actions=[                             
                            URITemplateAction(
                                label='即刻觀賞',
                                uri= link
                            ),
                            MessageTemplateAction(
                                label='打開選單',
                                text='打開選單'
                            ),
                        ]
                    )
                )
               

                count+=1
            else:
                break

        # 先建置好格式再回傳到view的line_bot_api.reply_message()
        Carousel_template = TemplateSendMessage(
                alt_text='Carousel template',
                template= CarouselTemplate(
                columns=
                [movie for movie in movieList] #迴圈內所建置CarouselColumn格式
        )
        )
        return Carousel_template  
                    

                    